<?php
require_once '../config.php';

try {
    // Create signatories table
    $sql = "CREATE TABLE IF NOT EXISTS signatories (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name1 VARCHAR(255) NOT NULL,
        `rank1` VARCHAR(255) NOT NULL,
        name2 VARCHAR(255) NOT NULL,
        `rank2` VARCHAR(255) NOT NULL,
        name3 VARCHAR(255) NOT NULL,
        `rank3` VARCHAR(255) NOT NULL,
        name4 VARCHAR(255) NOT NULL,
        `rank4` VARCHAR(255) NOT NULL,
        name5 VARCHAR(255) NOT NULL,
        `rank5` VARCHAR(255) NOT NULL,
        campus VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "Signatories table created successfully";
} catch(PDOException $e) {
    echo "Error creating table: " . $e->getMessage();
}
?> 