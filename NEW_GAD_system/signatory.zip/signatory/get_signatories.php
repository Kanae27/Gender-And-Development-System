<?php
require_once '../config.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Set headers
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
    ]);
    exit;
}

try {
    // Get campus from session
    $campus = $_SESSION['username'];
    $isCentral = ($campus === 'Central');
    
    // Check if the signatories table exists
    $tableCheck = $pdo->query("SHOW TABLES LIKE 'signatories'");
    if ($tableCheck->rowCount() == 0) {
        // Table doesn't exist, create it
        $createTableSql = "CREATE TABLE IF NOT EXISTS signatories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name1 VARCHAR(255) NOT NULL,
            `rank1` VARCHAR(255) NOT NULL,
            name2 VARCHAR(255) NOT NULL,
            `rank2` VARCHAR(255) NOT NULL,
            name3 VARCHAR(255) NOT NULL,
            `rank3` VARCHAR(255) NOT NULL,
            name4 VARCHAR(255) NOT NULL,
            `rank4` VARCHAR(255) NOT NULL,
            name5 VARCHAR(255) NOT NULL,
            `rank5` VARCHAR(255) NOT NULL,
            campus VARCHAR(255) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )";
        $pdo->exec($createTableSql);
    }
    
    // Get the current table structure
    $columnCheck = $pdo->query("SHOW COLUMNS FROM signatories");
    $columns = $columnCheck->fetchAll(PDO::FETCH_COLUMN);
    
    // Check if we need to use the old or new column names
    $hasNewColumns = in_array('name1', $columns) && in_array('rank1', $columns);
    
    if ($hasNewColumns) {
        // Use new column names
        if ($isCentral) {
            // For Central user, get ALL campus signatories
            $stmt = $pdo->prepare("SELECT id, name1, `rank1`, name2, `rank2`, name3, `rank3`, name4, `rank4`, name5, `rank5`, 
                                  campus, created_at, updated_at 
                                  FROM signatories");
            $stmt->execute();
        } else {
            // For campus-specific users, get only their campus
            $stmt = $pdo->prepare("SELECT id, name1, `rank1`, name2, `rank2`, name3, `rank3`, name4, `rank4`, name5, `rank5`, 
                                  campus, created_at, updated_at 
                                  FROM signatories WHERE campus = ?");
            $stmt->execute([$campus]);
        }
    } else {
        // Use old column names (for backward compatibility)
        if ($isCentral) {
            $stmt = $pdo->prepare("SELECT id, name, `rank`, campus, created_at, updated_at 
                                  FROM signatories");
            $stmt->execute();
        } else {
            $stmt = $pdo->prepare("SELECT id, name, `rank`, campus, created_at, updated_at 
                                  FROM signatories WHERE campus = ?");
            $stmt->execute([$campus]);
        }
    }
    
    $signatories = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If using old structure but found data, map to new structure
    if (!$hasNewColumns && !empty($signatories)) {
        foreach ($signatories as &$signatory) {
            $signatory['name1'] = $signatory['name'] ?? '';
            $signatory['rank1'] = $signatory['rank'] ?? '';
            $signatory['name2'] = '';
            $signatory['rank2'] = '';
            $signatory['name3'] = '';
            $signatory['rank3'] = '';
            $signatory['name4'] = '';
            $signatory['rank4'] = '';
            $signatory['name5'] = '';
            $signatory['rank5'] = '';
        }
    }
    
    // If no data found for current campus, add default structure
    if (empty($signatories) && !$isCentral) {
        $signatories = [
            [
                'id' => 0,
                'name1' => '',
                'rank1' => 'GAD Head Secretariat',
                'name2' => '',
                'rank2' => 'Vice Chancellor For Research, Development and Extension',
                'name3' => '',
                'rank3' => 'Chancellor',
                'name4' => '',
                'rank4' => 'Assistant Director For GAD Advocacies',
                'name5' => '',
                'rank5' => 'Head of Extension Services',
                'campus' => $campus,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]
        ];
    }
    
    // Debug output
    error_log("get_signatories.php - User: $campus, Central: " . ($isCentral ? 'Yes' : 'No') . ", Record count: " . count($signatories));
    foreach ($signatories as $index => $sig) {
        error_log("  Record $index: ID=" . $sig['id'] . ", Campus=" . $sig['campus']);
    }
    
    echo json_encode([
        'status' => 'success',
        'data' => $signatories
    ]);
    
} catch (Exception $e) {
    error_log("Error in get_signatories.php: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'An error occurred while fetching signatories: ' . $e->getMessage()
    ]);
}
?> 