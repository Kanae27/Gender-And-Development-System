<?php
session_start();
require_once('../includes/db_connection.php');

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

// Get parameters
$year = $_GET['year'] ?? null;
$campus = $_GET['campus'] ?? null;
$quarter = $_GET['quarter'] ?? null;

if (!$year || !$campus || !$quarter) {
    echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
    exit();
}

// Modify the quarter parameter to handle both formats
if (!preg_match('/^Q[1-4]$/', $quarter)) {
    $quarter = 'Q' . $quarter;
}

try {
    // Query to get titles from PPAS data
    $query = "SELECT p.id, p.title 
              FROM ppas_forms p 
              WHERE p.year = :year 
              AND p.created_by = :campus 
              AND p.quarter = :quarter";
    
    $stmt = $conn->prepare($query);
    $params = [
        ':year' => $year,
        ':campus' => $campus,
        ':quarter' => $quarter
    ];
    
    // Log the query and parameters for debugging
    error_log("Query: " . $query);
    error_log("Parameters: " . print_r($params, true));
    
    $stmt->execute($params);
    
    $titles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($titles) {
        echo json_encode([
            'success' => true,
            'titles' => $titles
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No available titles found for the selected criteria'
        ]);
    }
} catch (PDOException $e) {
    // Log the full error details
    error_log("Database error in get_titles.php: " . $e->getMessage());
    error_log("Error code: " . $e->getCode());
    error_log("Error info: " . print_r($e->errorInfo, true));
    
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} 