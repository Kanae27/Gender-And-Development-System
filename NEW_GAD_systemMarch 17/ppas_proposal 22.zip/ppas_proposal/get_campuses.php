<?php
require_once('../includes/db_connection.php');
header('Content-Type: application/json');

try {
    // Get distinct campuses from ppas_forms table
    $sql = "SELECT DISTINCT created_by as campus FROM ppas_forms WHERE created_by IS NOT NULL ORDER BY created_by";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    
    $campuses = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'data' => $campuses
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching campuses: ' . $e->getMessage()
    ]);
}
?> 