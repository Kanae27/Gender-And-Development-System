<?php
// Prevent any output before headers
ob_start();

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Start session and set headers
session_start();
header('Content-Type: application/json; charset=utf-8');

// Function to send JSON response
function sendJsonResponse($success, $data = null, $message = '') {
    $response = [
        'success' => $success,
        'message' => $message
    ];
    
    if ($data !== null) {
        $response['details'] = $data;
    }
    
    echo json_encode($response);
    exit;
}

try {
    // Include database connection
    require_once('../includes/db_connection.php');
    
    // Get and validate parameters
    $title_id = isset($_GET['title_id']) ? intval($_GET['title_id']) : null;
    $year = isset($_GET['year']) ? intval($_GET['year']) : null;
    $campus = isset($_GET['campus']) ? trim($_GET['campus']) : null;
    $quarter = isset($_GET['quarter']) ? trim($_GET['quarter']) : null;

    // Standardize quarter format (remove 'Q' prefix if present)
    $quarter = str_replace('Q', '', $quarter);

    // Log received parameters
    error_log("Received parameters for title details: " . json_encode([
        'title_id' => $title_id,
        'year' => $year,
        'campus' => $campus,
        'quarter' => $quarter
    ]));

    // Validate required parameters
    if (!$title_id || !$year || !$campus || !$quarter) {
        throw new Exception('Missing required parameters');
    }

    // First get the form details by ID only, but only if it has personnel
    $sql = "SELECT 
                f.id,
                f.title,
                f.location as venue,
                f.start_date,
                f.end_date,
                f.start_time,
                f.end_time,
                f.approved_budget,
                f.source_of_budget,
                f.year,
                f.quarter,
                f.location,
                f.created_by,
                GROUP_CONCAT(DISTINCT CASE WHEN p.role = 'Project Leader' THEN p.personnel_name END) as project_leaders,
                GROUP_CONCAT(DISTINCT CASE WHEN p.role = 'Assistant Project Leader' THEN p.personnel_name END) as assistant_leaders,
                GROUP_CONCAT(DISTINCT CASE WHEN p.role = 'Project Staff' THEN p.personnel_name END) as project_staff
            FROM ppas_forms f
            INNER JOIN ppas_personnel p ON f.id = p.ppas_id
            WHERE f.id = :title_id
            GROUP BY f.id";

    // Log SQL query and parameters
    error_log("SQL Query for form: " . $sql);
    error_log("Parameters: " . json_encode(['title_id' => $title_id]));

    // Prepare and execute statement
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Failed to prepare statement");
    }

    // Bind parameters
    $stmt->bindParam(':title_id', $title_id, PDO::PARAM_INT);

    // Execute the query
    if (!$stmt->execute()) {
        throw new Exception("Failed to execute query");
    }

    // Fetch the form details
    $details = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$details) {
        // Let's check if the title exists and has personnel
        $checkSql = "SELECT f.id, f.title, f.year, f.quarter, f.location, f.created_by, COUNT(p.id) as personnel_count 
                     FROM ppas_forms f 
                     LEFT JOIN ppas_personnel p ON f.id = p.ppas_id 
                     WHERE f.id = :title_id 
                     GROUP BY f.id";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bindParam(':title_id', $title_id, PDO::PARAM_INT);
        $checkStmt->execute();
        $titleCheck = $checkStmt->fetch(PDO::FETCH_ASSOC);

        if (!$titleCheck) {
            echo json_encode([
                'success' => false,
                'message' => "Title with ID $title_id not found in database"
            ]);
        } else if ($titleCheck['personnel_count'] == 0) {
            echo json_encode([
                'success' => false,
                'message' => "Title found but has no assigned personnel",
                'debug_info' => [
                    'requested' => [
                        'title_id' => $title_id,
                        'year' => $year,
                        'quarter' => $quarter,
                        'campus' => $campus
                    ],
                    'found_in_db' => $titleCheck
                ]
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => "Title found but may have missing required fields",
                'debug_info' => [
                    'requested' => [
                        'title_id' => $title_id,
                        'year' => $year,
                        'quarter' => $quarter,
                        'campus' => $campus
                    ],
                    'found_in_db' => $titleCheck
                ]
            ]);
        }
        exit;
    }

    // Debug log the raw details
    error_log("Raw form details for title_id $title_id: " . json_encode($details));

    // Format personnel arrays
    $details['project_leaders'] = array_filter(explode(',', $details['project_leaders']));
    $details['assistant_leaders'] = array_filter(explode(',', $details['assistant_leaders']));
    $details['project_staff'] = array_filter(explode(',', $details['project_staff']));

    // Format dates if they exist
    if (isset($details['start_date'])) {
        $details['start_date'] = date('Y-m-d', strtotime($details['start_date']));
    }
    if (isset($details['end_date'])) {
        $details['end_date'] = date('Y-m-d', strtotime($details['end_date']));
    }

    // Debug log the comparison values
    error_log("Comparing values for title_id $title_id:");
    error_log("Year - Requested: $year, DB: {$details['year']}");
    error_log("Quarter - Requested: $quarter, DB: {$details['quarter']}");
    error_log("Campus - Requested: $campus, DB: {$details['location']}");
    error_log("Created By: {$details['created_by']}");

    // Check if the year, quarter, and campus match
    $yearMatch = ($details['year'] == $year);
    $quarterMatch = (str_replace('Q', '', $details['quarter']) == str_replace('Q', '', $quarter));
    
    // Use created_by for campus matching if location is empty or incorrect
    $campusMatch = false;
    if (!empty($details['location']) && strcasecmp(trim($details['location']), trim($campus)) === 0) {
        $campusMatch = true;
    } else if (!empty($details['created_by']) && strcasecmp(trim($details['created_by']), trim($campus)) === 0) {
        $campusMatch = true;
        // Update the location field with the correct campus
        $details['location'] = $details['created_by'];
    }

    if (!$yearMatch || !$quarterMatch || !$campusMatch) {
        // Debug log the comparison results
        error_log("Mismatch found for title_id $title_id:");
        error_log("Year match: " . ($yearMatch ? 'true' : 'false'));
        error_log("Quarter match: " . ($quarterMatch ? 'true' : 'false'));
        error_log("Campus match: " . ($campusMatch ? 'true' : 'false'));
        
        echo json_encode([
            'success' => false,
            'message' => "Please use: Year: {$details['year']}, Quarter: {$details['quarter']}, Campus: {$details['created_by']}",
            'debug_info' => [
                'requested' => [
                    'year' => $year,
                    'quarter' => $quarter,
                    'campus' => $campus,
                    'title_id' => $title_id
                ],
                'found_in_db' => [
                    'year' => $details['year'],
                    'quarter' => $details['quarter'],
                    'location' => $details['location'],
                    'created_by' => $details['created_by'],
                    'title' => $details['title']
                ],
                'comparison_results' => [
                    'year_match' => $yearMatch,
                    'quarter_match' => $quarterMatch,
                    'campus_match' => $campusMatch
                ]
            ]
        ]);
        exit;
    }

    // Ensure all required fields are present
    $requiredFields = [
        'project_leaders' => [],
        'assistant_leaders' => [],
        'project_staff' => [],
        'start_date' => '',
        'end_date' => '',
        'start_time' => '',
        'end_time' => '',
        'approved_budget' => '',
        'source_of_budget' => ''
    ];

    foreach ($requiredFields as $field => $default) {
        if (!isset($details[$field])) {
            $details[$field] = $default;
        }
    }

    echo json_encode([
        'success' => true,
        'details' => $details
    ]);

} catch (Exception $e) {
    error_log("Error in get_title_details.php: " . $e->getMessage());
    
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while fetching title details: ' . $e->getMessage()
    ]);
} finally {
    ob_end_flush();
}
?> 