<?php
session_start();

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set JSON header
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit();
}

try {
    // Include database connection
    require_once('../includes/db_connection.php');
    
    // Get database connection
    $conn = getConnection();

    $campus = isset($_GET['campus']) ? $_GET['campus'] : null;
    $year = isset($_GET['year']) ? $_GET['year'] : null;

    // If no year is provided, return available years
    if (!$year) {
        $sql = "SELECT DISTINCT year FROM ppas_forms ORDER BY year DESC";
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        
        $years = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo json_encode([
            'success' => true,
            'years' => $years,
            'message' => empty($years) ? 'No years available' : null
        ]);
        exit;
    }

    // If year is provided but no campus, return available campuses for that year
    if (!$campus) {
        $sql = "SELECT DISTINCT created_by as campus FROM ppas_forms WHERE year = :year ORDER BY created_by";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':year', $year);
        $stmt->execute();
        
        $campuses = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        echo json_encode([
            'success' => true,
            'campuses' => $campuses,
            'message' => empty($campuses) ? 'No campuses available for the selected year' : null
        ]);
        exit;
    }

    // If both year and campus are provided, return available quarters
    if ($year && $campus) {
        // Get quarters for selected year and campus
        $sql = "SELECT DISTINCT quarter FROM ppas_forms 
                WHERE year = :year AND created_by = :campus 
                ORDER BY quarter ASC";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':year' => $year,
            ':campus' => $campus
        ]);
        
        $quarters = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Remove 'Q' prefix for consistent formatting
        $quarters = array_map(function($q) {
            return trim(str_replace('Q', '', $q));
        }, $quarters);
        
        // Remove duplicates and sort
        $quarters = array_unique($quarters);
        sort($quarters);
        
        echo json_encode([
            'success' => true,
            'quarters' => $quarters
        ]);
        exit();
    }

} catch (PDOException $e) {
    error_log("Database error in get_available_data.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database connection error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log("General error in get_available_data.php: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred: ' . $e->getMessage()
    ]);
}
exit(); 