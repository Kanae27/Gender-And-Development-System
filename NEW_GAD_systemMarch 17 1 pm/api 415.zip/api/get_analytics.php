<?php
require_once '../config.php';

header('Content-Type: application/json');

$response = [
    'success' => false,
    'data' => [],
    'message' => ''
];

try {
    // Get parameters
    $campus = isset($_GET['campus']) ? $_GET['campus'] : null;
    $year = isset($_GET['year']) ? $_GET['year'] : null;

    // Base query for analytics
    $query = "SELECT 
        COUNT(DISTINCT id) as total_activities,
        COALESCE(SUM(male_participants), 0) as total_male,
        COALESCE(SUM(female_participants), 0) as total_female,
        COALESCE(SUM(total_participants), 0) as total_participants,
        COALESCE(SUM(gad_budget), 0) as total_budget,
        COUNT(DISTINCT CASE WHEN generic_activity IS NOT NULL AND generic_activity != '' 
            THEN generic_activity END) as generic_activities,
        COUNT(DISTINCT CASE WHEN specific_activities IS NOT NULL AND specific_activities != '' 
            THEN specific_activities END) as specific_activities
    FROM gpb_entries
    WHERE 1=1";

    $params = [];
    
    // Add filters if provided
    if ($campus) {
        $query .= " AND campus = ?";
        $params[] = $campus;
    }
    if ($year) {
        $query .= " AND year = ?";
        $params[] = $year;
    }

    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $analytics = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get total GAA and calculate budget percentage
    $totalBudget = floatval($analytics['total_budget']);
    $budgetPercentage = 0;

    if ($totalBudget > 0) {
        $gaaQuery = "SELECT SUM(gad_budget) as total_gaa FROM gpb_entries";
        if ($campus && $year) {
            $gaaQuery .= " WHERE campus = ? AND year = ?";
        }
        $stmt = $pdo->prepare($gaaQuery);
        $stmt->execute($params);
        $gaaData = $stmt->fetch(PDO::FETCH_ASSOC);
        $totalGAA = floatval($gaaData['total_gaa']);
        $budgetPercentage = $totalGAA > 0 ? ($totalBudget / $totalGAA) * 100 : 0;
    }

    $response['data'] = [
        'total_activities' => intval($analytics['total_activities']),
        'total_male' => intval($analytics['total_male']),
        'total_female' => intval($analytics['total_female']),
        'total_participants' => intval($analytics['total_participants']),
        'total_budget' => $totalBudget,
        'budget_percentage' => round($budgetPercentage, 2),
        'generic_activities' => intval($analytics['generic_activities']),
        'specific_activities' => intval($analytics['specific_activities'])
    ];

    $response['success'] = true;

} catch (Exception $e) {
    $response['message'] = "Error: " . $e->getMessage();
    error_log("Error in get_analytics.php: " . $e->getMessage());
}

echo json_encode($response); 