<?php
require_once '../config.php';

// Set appropriate headers
header('Content-Type: application/json');

// Initialize response
$response = [
    'success' => false,
    'data' => [],
    'debug' => []
];

try {
    // Get search term from request
    $search_term = isset($_GET['term']) ? trim($_GET['term']) : '';
    $response['debug']['raw_term'] = $_GET['term'] ?? 'not set';
    
    // Check if PDO connection exists
    if (!isset($pdo) || !$pdo) {
        throw new Exception("Database connection not established");
    }
    
    // Set PDO to throw exceptions on error
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Test connection
    $pdo->query("SELECT 1");
    $response['debug']['connection'] = 'Connected successfully';
    
    // Check if table exists
    $table_check = $pdo->query("SHOW TABLES LIKE 'gpb_entries'");
    $table_exists = $table_check->rowCount() > 0;
    $response['debug']['table_exists'] = $table_exists;
    
    if (!$table_exists) {
        $response['debug']['error'] = 'Table gpb_entries does not exist';
        throw new Exception("Table gpb_entries does not exist");
    }
    
    // Check if there are any records in the table
    $count_check = $pdo->query("SELECT COUNT(*) FROM gpb_entries WHERE gender_issue IS NOT NULL");
    $total_count = $count_check->fetchColumn();
    $response['debug']['total_records'] = $total_count;
    
    // Prepare the search query
    $sql = "SELECT DISTINCT gender_issue 
            FROM gpb_entries 
            WHERE gender_issue IS NOT NULL 
            AND TRIM(gender_issue) != '' 
            AND gender_issue LIKE :search_term
            ORDER BY gender_issue
            LIMIT 10";
    
    $search_param = '%' . $search_term . '%';
    $response['debug']['search_param'] = $search_param;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['search_term' => $search_param]);
    $issues = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // If no issues found with the search term, return empty array
    if (empty($issues) && !empty($search_term)) {
        $response['debug']['message'] = 'No matching gender issues found';
        
        // Get some sample data to help debug
        $sample_stmt = $pdo->query("SELECT DISTINCT gender_issue FROM gpb_entries WHERE gender_issue IS NOT NULL LIMIT 5");
        $sample_issues = $sample_stmt->fetchAll(PDO::FETCH_COLUMN);
        $response['debug']['sample_issues'] = $sample_issues;
    }
    
    $response['success'] = true;
    $response['data'] = $issues;
    $response['debug']['count'] = count($issues);
    $response['debug']['query'] = $sql;
    $response['debug']['search_term'] = $search_term;
    
} catch (Exception $e) {
    error_log("Error in search_gender_issues.php: " . $e->getMessage());
    $response['error'] = $e->getMessage();
    $response['debug']['exception'] = $e->getMessage();
}

// Return JSON response
echo json_encode($response);
exit; 