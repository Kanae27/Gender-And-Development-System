<?php
require_once '../config.php';

$campus_id = $_GET['campus_id'] ?? '';
$response = ['success' => false, 'data' => []];

try {
    if (!$campus_id) {
        throw new Exception('Campus ID is required');
    }

    // Get years for the selected campus
    $stmt = $pdo->prepare("SELECT DISTINCT year as id, year as year FROM target WHERE campus = ? ORDER BY year DESC");
    $stmt->execute([$campus_id]);
    $years = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($years) {
        $response['success'] = true;
        $response['data'] = $years;
    }
} catch(Exception $e) {
    error_log("Error fetching years: " . $e->getMessage());
    $response['message'] = $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode($response['data']); 